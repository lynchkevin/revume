"use strict";

 angular.module('config', [])

.constant('baseUrl', {name:'development',endpoint:'http://192.168.1.167:5000',volerro:'https://rb.volerro.com'})

;