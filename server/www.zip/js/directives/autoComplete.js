'use strict';

/**
* autocomplete username and email   
*/
angular.module('starter')
    .directive('userComplete',['userService',
    function (userService) {
      return {
        restrict : 'A',
        scope:{
            fieldType: '@fieldType',
            instanceName: '@instanceName',
        },
        link: function(scope, element, attrs) {
            var el = element[0];
            //save the model so we can auto-fill it later
            scope.model = $parse(attrs.ngModel);
            
            //initialize the autocomplete popover
            $ionicPopover.fromTemplateUrl('templates/autocomplete.html', {
                scope: scope,
            }).then(function(pop) {
                scope.popover = pop;
            });
            
            //the popover will call this on our scope
            scope.finishComplete = function($index){
                userService.doAutoComplete(scope,$index);
            };
            
            //the user service will call this callback on do AutoComplete for all instances with same name
            scope.doFinish = function($index){
                var user = scope.entries[$index];
                switch(scope.fieldType){
                        case 'name' : 
                                var name = user.firstName+' '+user.lastName;
                                scope.model.assign(name);
                                scope.popover.hide();
                                break;
                        case 'email' :
                                scope.model.assign(user.email);
                                scope.popover.hide();
                                break;
                }
            };
            //connect the callback
            userService.onAutoComplete(scope);
            
            scope.$watch(attrs.ngModel, function (str) {
                console.log('value changed, new value is: ' + str,'type=',inputType);
                switch(scope.fieldType){
                        case 'name' : 
                                    if(str!=undefined)
                                        if(str.length>0){
                                            var query={first:str};
                                            userService.find(query).then(function(results){
                                                scope.entries = results;
                                                if(results.length>0)
                                                    popover.show(el);
                                                else
                                                    popover.hide();
                                            });
                                        } else {
                                            popover.hide();
                                        }   
                                        break;
                        case 'email' :
                                    if(str != undefined)
                                        if(str.indexOf('@')>0){
                                            var query={email:str};
                                            userService.find(query).then(function(results){
                                                $scope.autoComplete.entries = results;
                                                if(results.length>0)
                                                    popover.show(el);
                                                else
                                                    popover.hide();
                                            });
                                        } 
                                        break;
                }
            });
            
            scope.$on('$destroy',function(){
                scope.popover.remove();
                userService.offAutoComplete(scope);
            });
                
        } 
    };
}]);