`ng-flow-standalone.js` - Flow.js + ng-flow, everything that you need is in this one file.

`ng-flow.js` - ng-flow only, you have to include flow.js yourself.